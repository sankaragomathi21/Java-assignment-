package controlflow;

import java.util.*;

public class Flow3 {

  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    int num = s.nextInt();
    if (num % 2 != 0) {
      num = (num * 3) + 1;
    } else {
      num /= 2;
    }
    System.out.println("Current Number " + num);
    s.close();
  }
}
