package controlflow;

import java.util.*;

public class Flow5 {

  public static boolean isPalindrome(int n) {
    int r, sum = 0, temp;
    temp = n;
    while (n > 0) {
      r = n % 10; //getting remainder
      sum = (sum * 10) + r;
      n = n / 10;
    }
    return temp == sum;
  }

  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    int a = s.nextInt();
    int b = s.nextInt();
    for (int i = a; i <= b; i++) {
      if (isPalindrome(i)) {
        System.out.println(i);
      }
    }
    s.close();
  }
}
