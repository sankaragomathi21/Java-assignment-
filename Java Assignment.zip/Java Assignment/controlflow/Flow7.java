package controlflow;

import java.util.*;

public class Flow7 {

  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    int choice;
    do {
      System.out.println("1: Display month");
      System.out.println("2: Display Week");
      System.out.println("3: Exit");
      choice = s.nextInt();
      switch (choice) {
        case 1:
          System.out.println(
            "1.January\n2.February\n3.March\n4.April\n5.May\n6.June\n7.July\n8.August\n9.September\n10.October\n11.November\n12.December"
          );
          break;
        case 2:
          System.out.println(
            "1.Sunday\n2.Momday\n3.Tuesday\n4.Wednesday\n5.Thursday\n6.Friday\n7.Saturday"
          );
          break;
        default:
          break;
      }
    } while (choice != 3);
    s.close();
  }
}
