package controlflow;

import java.util.*;

public class Flow4 {

  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    int a = s.nextInt();
    int b = s.nextInt();
    if (a > 12 && a < 20 || b > 12 && b < 20) {
      System.out.println("teen sum " + 19);
    } else {
      System.out.println("teen sum " + (a + b));
    }
    s.close();
  }
}
