package controlflow;

import java.util.*;

class Flow2 {

  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    int itemPurchased = s.nextInt();
    double ratePerItem = s.nextDouble();
    double totalExpense = itemPurchased * ratePerItem;
    if (itemPurchased > 1000) {
      totalExpense = totalExpense - (totalExpense * 10) / 100;
    }
    System.out.println("Total Expenses " + totalExpense);
    s.close();
  }
}
