package controlflow;

import java.util.*;

class Flow1 {

  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    int code = s.nextInt();
    if (code != 1) {
      s.close();
      return;
    }
    double x = s.nextDouble();
    double y = s.nextDouble();
    double sum = x + y;
    System.out.println("Sum is " + sum);
    s.close();
  }
}
