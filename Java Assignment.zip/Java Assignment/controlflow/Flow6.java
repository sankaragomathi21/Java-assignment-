package controlflow;

import java.util.*;

public class Flow6 {

  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    Random random = new Random();
    int number = random.nextInt(1000);
    int guess = s.nextInt();
    while (guess != number) {
      if (guess < number) {
        System.out.println("Try higher");
      } else if (guess > number) {
        System.out.println("Try lower");
      } else {
        System.out.println("Correct");
        continue;
      }
      guess = s.nextInt();
    }
    s.close();
  }
}
