package controlflow;

import java.util.*;

public class Flow8 {

  public static void main(String args[]) {
    int number;
    Scanner s = new Scanner(System.in);
    number = s.nextInt();

    for (int i = 2; i < number; i++) {
      while (number % i == 0) {
        System.out.print(i + " ");
        number = number / i;
      }
    }
    if (number > 2) {
      System.out.print(number);
    }
    s.close();
  }
}
