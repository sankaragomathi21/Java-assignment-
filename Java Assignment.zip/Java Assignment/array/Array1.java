package array;

import java.util.*;
import java.util.Map.Entry;

public class Array1 {

  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    int n = s.nextInt();
    int[] arr = new int[n];
    for (int i = 0; i < n; i++) {
      arr[i] = s.nextInt();
    }
    HashMap<Integer, Integer> hashMap = new HashMap<>();

    for (int i = 0; i < n; i++) {
      if (!hashMap.containsKey(arr[i])) {
        hashMap.put(arr[i], 1);
      } else {
        int val = hashMap.get(arr[i]);
        hashMap.replace(arr[i], val++);
      }
    }

    int noOfUnique = 0, noOfDuplicate = 0;

    for (Entry<Integer, Integer> entry : hashMap.entrySet()) {
      System.out.println(entry.getValue());
      if (entry.getValue() > 1) noOfDuplicate++; else noOfUnique++;
    }
    System.out.println("No of Duplicate " + noOfDuplicate);
    System.out.println("No of Unique " + noOfUnique);
  }
}
